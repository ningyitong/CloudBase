/*
 Navicat MySQL Data Transfer

 Source Server         : 123.207.244.139@test
 Source Server Type    : MySQL
 Source Server Version : 50173
 Source Host           : 123.207.244.139:3306
 Source Schema         : bank

 Target Server Type    : MySQL
 Target Server Version : 50173
 File Encoding         : 65001

 Date: 28/04/2018 08:01:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for indent
-- ----------------------------
DROP TABLE IF EXISTS `indent`;
CREATE TABLE `indent`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` bigint(45) NULL DEFAULT NULL,
  `user_id` int(11) NULL DEFAULT NULL,
  `login_service_provider_id` int(11) NULL DEFAULT NULL,
  `bank_service_provider_id` int(11) NULL DEFAULT NULL,
  `balance` int(11) NULL DEFAULT NULL,
  `app_develop_provider_id` int(11) NULL DEFAULT NULL,
  `cost` decimal(10, 2) NULL DEFAULT 5.00,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 67 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of indent
-- ----------------------------
INSERT INTO `indent` VALUES (32, 1524833471253, 9, 1, 1, 995, 1, 5.00);
INSERT INTO `indent` VALUES (33, 1524834011265, 9, 1, 1, 990, 1, 5.00);
INSERT INTO `indent` VALUES (34, 1524834279678, 12, 1, 1, 995, 1, 5.00);
INSERT INTO `indent` VALUES (35, 1524834727525, 9, 1, 1, 985, 1, 5.00);
INSERT INTO `indent` VALUES (36, 1524835079370, 9, 1, 1, 980, 1, 5.00);
INSERT INTO `indent` VALUES (38, 1524836742759, 9, 1, 1, 975, 1, 5.00);
INSERT INTO `indent` VALUES (39, 1524838867208, 9, 1, 1, 970, 1, 5.00);
INSERT INTO `indent` VALUES (40, 1524839141476, 9, 1, 1, 965, 1, 5.00);
INSERT INTO `indent` VALUES (41, 1524839465013, 9, 1, 1, 960, 1, 5.00);
INSERT INTO `indent` VALUES (42, 1524839538797, 9, 1, 1, 955, 1, 5.00);
INSERT INTO `indent` VALUES (43, 1524839633533, 9, 1, 1, 950, 1, 5.00);
INSERT INTO `indent` VALUES (44, 1524843739798, 9, 1, 1, 945, 1, 5.00);
INSERT INTO `indent` VALUES (45, 1524843807200, 9, 1, 1, 940, 1, 5.00);
INSERT INTO `indent` VALUES (46, 1524843982450, 9, 1, 1, 935, 1, 5.00);
INSERT INTO `indent` VALUES (47, 1524844095521, 9, 1, 1, 930, 1, 5.00);
INSERT INTO `indent` VALUES (48, 1524844131195, 9, 1, 1, 925, 1, 5.00);
INSERT INTO `indent` VALUES (49, 1524844147151, 9, 1, 1, 920, 1, 5.00);
INSERT INTO `indent` VALUES (50, 1524844235664, 9, 1, 1, 915, 1, 5.00);
INSERT INTO `indent` VALUES (51, 1524844368318, 9, 1, 1, 910, 1, 5.00);
INSERT INTO `indent` VALUES (52, 1524844429999, 9, 1, 1, 905, 1, 5.00);
INSERT INTO `indent` VALUES (53, 1524844550093, 9, 1, 1, 900, 1, 5.00);
INSERT INTO `indent` VALUES (54, 1524844585403, 9, 1, 1, 895, 1, 5.00);
INSERT INTO `indent` VALUES (55, 1524844622671, 9, 1, 1, 890, 1, 5.00);
INSERT INTO `indent` VALUES (56, 1524844635242, 9, 1, 1, 885, 1, 5.00);
INSERT INTO `indent` VALUES (57, 1524845916330, 9, 1, 1, 880, 1, 5.00);
INSERT INTO `indent` VALUES (58, 1524846012779, 9, 1, 1, 875, 1, 5.00);
INSERT INTO `indent` VALUES (59, 1524872130572, 9, 1, 1, 870, 1, 5.00);
INSERT INTO `indent` VALUES (60, 1524872217329, 9, 1, 1, 865, 1, 5.00);
INSERT INTO `indent` VALUES (61, 1524872385725, 9, 1, 1, 860, 1, 5.00);
INSERT INTO `indent` VALUES (62, 1524872439233, 9, 1, 1, 855, 1, 5.00);
INSERT INTO `indent` VALUES (63, 1524872445712, 9, 1, 1, 850, 1, 5.00);
INSERT INTO `indent` VALUES (64, 1524873134511, 9, 1, 1, 845, 1, 5.00);
INSERT INTO `indent` VALUES (65, 1524873149656, 9, 1, 1, 840, 1, 5.00);
INSERT INTO `indent` VALUES (66, 1524873208058, 9, 1, 1, 835, 1, 5.00);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `question` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `answer` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `balance` int(11) NULL DEFAULT 1000,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'ning', 'ning', 'abc@email', NULL, NULL, 1165);
INSERT INTO `users` VALUES (9, 'test', 'test', 'test@email.com', NULL, NULL, 835);

SET FOREIGN_KEY_CHECKS = 1;
