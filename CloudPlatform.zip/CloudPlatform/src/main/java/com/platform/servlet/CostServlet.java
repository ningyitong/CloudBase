package com.platform.servlet;

import com.platform.dao.User;
import com.platform.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CostServlet extends BaseServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = (User) req.getSession().getAttribute("user");
        if (user == null) {
            String script1 ="<script>alert('Pay Failed!');</script>";
            resp.getWriter().print(script1);
        }
        new UserDao().cost(user);
        String href = (String) req.getParameter("href");
        System.out.println(href);

        String script1 ="<script>alert('Pay success!');window.location.href=" + href + "</script>";
        System.out.println(script1);
        resp.getWriter().print(script1);
    }
}
