package com.platform.servlet;

import com.platform.dao.User;
import com.platform.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class UpdateUserInfoServlet extends BaseServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = (User) req.getSession().getAttribute("user");
        user.setUsername((String) req.getParameter("username"));
        user.setEmail((String) req.getParameter("email"));
        new UserDao().updateUserInfo(user);
        req.getSession().setAttribute("user", user);
        req.getSession().setAttribute("username", user.getUsername());
        String script1 ="<script>alert('Update success!');location.href='user-info.jsp'</script>";
        resp.getWriter().print(script1);
    }
}
