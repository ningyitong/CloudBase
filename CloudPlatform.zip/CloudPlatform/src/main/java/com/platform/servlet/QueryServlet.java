package com.platform.servlet;

import com.platform.dao.User;
import com.platform.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class QueryServlet extends BaseServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        UserDao userDao = new UserDao();
        Object use = request.getSession().getAttribute("user");

        User user = null;
        user = (User)use;

        userDao.cost(user);
        PrintWriter out = response.getWriter();
    }
}
