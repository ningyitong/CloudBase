package com.platform.servlet;

import com.platform.dao.User;
import com.platform.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by ZJ on 2018/4/27.
 */
public class resetPassword extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        User user = (User) request.getSession().getAttribute("user");
        String old_password = request.getParameter("old_password");
        String new_password = request.getParameter("new_password");
        String re_new_password = request.getParameter("re_new_password");
        String name = user.getUsername();
        String password = user.getPassword();


        if (!old_password.equals(password)) {
            String script1 = "<script>alert('old not true ');location.href='resetPass.jsp'</script>";
            response.getWriter().print(script1);
        } else if (old_password.equals(new_password)) {
            String script1 = "<script>alert('old equal new ');location.href='resetPass.jsp'</script>";
            response.getWriter().print(script1);
        } else if (!new_password.equals(re_new_password)) {
            String script1 = "<script>alert('new not euqal re_new ');location.href='resetPass.jsp'</script>";
            response.getWriter().print(script1);
        } else if (re_new_password.equals(new_password)) {
            UserDao userDao = new UserDao();
            userDao.resetPass(new_password, name);
            String script1 = "<script>alert('resetPass success ');location.href='login.jsp'</script>";
            response.getWriter().print(script1);
        }
    }
}
