package com.platform.servlet;

import com.platform.dao.User;
import com.platform.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        UserDao userDao = new UserDao();
        User user = userDao.login(username, password);

        if (user != null) {
            session.setAttribute("user", user);
            session.setAttribute("username", username);
            //改为点击app时扣费
//            userDao.cost(user);
//            String script1 ="<script>alert('Log on successfully! Five dollar buckle');location.href='transaction.jsp'</script>";
            String script1 ="<script>alert('Login success!');location.href='app.jsp'</script>";
            response.getWriter().print(script1);
            //response.sendRedirect("transaction.jsp");
        } else {
            String script = "<script>alert('Login failed! Please check your username or password!');location.href='login.jsp'</script>";
            response.getWriter().println(script);
        }
    }
}
