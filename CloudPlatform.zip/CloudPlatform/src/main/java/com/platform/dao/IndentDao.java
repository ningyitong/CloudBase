package com.platform.dao;

import com.platform.sqltool.ConnectDB;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class IndentDao {
    /**
     * 扣除5peanut，按比例分配
     * @param indent
     * @return
     */
    public boolean costIndent(Indent indent) {
        Connection conn = ConnectDB.getConnection();
//        String sql = "insert into indent(username,password,email,question,answer) values(?,?,?,?,?)";
        String sql = "INSERT INTO indent(time, user_id, login_service_provider_id, bank_service_provider_id, balance, app_develop_provider_id) VALUE (?, ?, ?, ?, ?, ?)";
        String sql1 = "update users set balance = balance + 3 where id = " + indent.getApp_develop_provider_id();
        String sql2 = "update users set balance = balance + 1 where id = " + indent.getLogin_service_provider_id();
        String sql3 = "update users set balance = balance + 1 where id = " + indent.getBank_service_provider_id();
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, new Date().getTime());
            ps.setInt(2, indent.getUer_id());
            ps.setInt(3, indent.getLogin_service_provider_id());
            ps.setInt(4, indent.getBank_service_provider_id());
            ps.setInt(5, indent.getBalance());
            ps.setInt(6, indent.getApp_develop_provider_id());
            ps.execute();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            ConnectDB.closeConnection(conn);
        }

        Connection connection = ConnectDB.getConnection();
        try {
            connection.setAutoCommit(false);

            connection.createStatement().execute(sql1);
            connection.createStatement().execute(sql2);
            connection.createStatement().execute(sql3);
            connection.commit();

        } catch (SQLException e) {
            e.printStackTrace();
            try {
                connection.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            return false;
        } finally {
            ConnectDB.closeConnection(connection);
        }
        return true;
    }

    public List<Indent> selectById(int user_id) {
        List<Indent> list = new ArrayList<>();
        Connection conn = ConnectDB.getConnection();
        String sql = "select * from indent where user_id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, user_id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Indent e = new Indent();
                e.setId(rs.getInt(1));
                e.setTime(rs.getLong(2));
                e.setUer_id(rs.getInt(3));
                e.setLogin_service_provider_id(rs.getInt(4));
                e.setBank_service_provider_id(rs.getInt(5));
                e.setBalance(rs.getInt(6));
                e.setApp_develop_provider_id(rs.getInt(7));
                list.add(e);
            }

            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectDB.closeConnection(conn);
        }
        return list;
    }

}
