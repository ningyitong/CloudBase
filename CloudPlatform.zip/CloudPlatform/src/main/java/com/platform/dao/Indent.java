package com.platform.dao;

public class Indent {
    private int id;
    private long time;
    private int uer_id;
    private int login_service_provider_id;
    private int bank_service_provider_id;
    private int app_develop_provider_id;
    private int balance;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public int getUer_id() {
        return uer_id;
    }

    public void setUer_id(int uer_id) {
        this.uer_id = uer_id;
    }

    public int getLogin_service_provider_id() {
        return login_service_provider_id;
    }

    public void setLogin_service_provider_id(int login_service_provider_id) {
        this.login_service_provider_id = login_service_provider_id;
    }

    public int getBank_service_provider_id() {
        return bank_service_provider_id;
    }

    public void setBank_service_provider_id(int bank_service_provider_id) {
        this.bank_service_provider_id = bank_service_provider_id;
    }

    public int getApp_develop_provider_id() {
        return app_develop_provider_id;
    }

    public void setApp_develop_provider_id(int app_develop_provider_id) {
        this.app_develop_provider_id = app_develop_provider_id;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }
}
