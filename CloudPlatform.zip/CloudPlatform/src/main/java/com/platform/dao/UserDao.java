package com.platform.dao;

import com.platform.sqltool.ConnectDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class UserDao {

    // save user to DB
    public void saveUser(User user) {
        Connection conn = ConnectDB.getConnection();
        String sql = "insert into users(username,password,email,question,answer) values(?,?,?,?,?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getQuestion());
            ps.setString(5, user.getAnswer());

            ps.executeUpdate();

            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ConnectDB.closeConnection(conn);
        }
    }

    // validate username cannot be duplicated

    /**
     * @param username
     * @return true if a same username is exist.
     */
    public boolean isSameUsername(String username) {
        Connection conn = ConnectDB.getConnection();
        String sql = "select * from users where username = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return true;
            }

            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectDB.closeConnection(conn);
        }
        return false;
    }

    // verify username and password
    public User login(String username, String password) {
        User user = null;
        Connection conn = ConnectDB.getConnection();
        String sql = "select * from users where username = ? and password = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                user = new User();

                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setEmail(rs.getString("email"));
                user.setQuestion(rs.getString("question"));
                user.setAnswer(rs.getString("answer"));
                user.setBalance(rs.getInt("balance"));
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ConnectDB.closeConnection(conn);
        }
        return user;
    }

    public boolean cost(User user) {
        boolean result = true;
        Connection conn = ConnectDB.getConnection();
        String sql = "UPDATE users SET balance = balance - 5 WHERE username = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, user.getUsername());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            ConnectDB.closeConnection(conn);
        }

        Indent indent = new Indent();
        indent.setTime(new Date().getTime());
        indent.setUer_id(user.getId());
        indent.setLogin_service_provider_id(1);
        indent.setBank_service_provider_id(1);
        indent.setApp_develop_provider_id(1);
        indent.setBalance(balance(user.getUsername()));
        return new IndentDao().costIndent(indent);
    }

    public int resetPass(String newPassword,String username) {

        Connection conn = ConnectDB.getConnection();
        String sql ="UPDATE users SET password = ? WHERE username = ?";

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1,newPassword);
            ps.setString(2,username);
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ConnectDB.closeConnection(conn);
        }
        return 1;
    }

    public int balance(String username) {
        int balance = 0;
        Connection conn = ConnectDB.getConnection();
        String sql = "select balance from users where username = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                balance = rs.getInt("balance");
            }

            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ConnectDB.closeConnection(conn);
        }
        return balance;
    }

    public boolean updateUserInfo(User user) {
        boolean result = false;
        Connection conn = ConnectDB.getConnection();
        String sql = "update users set username = ?, email = ? where id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            ps.setInt(3, user.getId());
            ps.execute();

            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            ConnectDB.closeConnection(conn);
        }
        return true;

    }
}
