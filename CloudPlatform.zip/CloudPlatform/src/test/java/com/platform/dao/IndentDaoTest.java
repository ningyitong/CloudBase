package com.platform.dao;

import com.google.gson.Gson;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.List;

public class IndentDaoTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void selectBuId() {
        IndentDao id = new IndentDao();
        List<Indent> list = id.selectById(1);
        System.out.println(new Gson().toJson(list));
    }

    @Test
    public void login() {
    }
}