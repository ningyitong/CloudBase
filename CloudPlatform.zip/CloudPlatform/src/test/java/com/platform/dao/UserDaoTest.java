package com.platform.dao;

import com.google.gson.Gson;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class UserDaoTest {
    UserDao ud = new UserDao();

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void saveUser() {
        User user = new User();
        user.setUsername("auto");
        user.setPassword("auto");
        ud.saveUser(user);
    }

    @Test
    public void sameUsername() {
        System.out.println(ud.isSameUsername("test1"));
        System.out.println(ud.isSameUsername("test"));
    }

    @Test
    public void cost() {
        User user = ud.login("test", "test");
        ud.cost(user);
        System.out.println(new Gson().toJson(user));
    }

    @Test
    public void balance() {
        System.out.println(ud.balance("test"));
    }

    @Test
    public void updateUserInfo() {
        User user = new User();
        user.setId(8);
        user.setEmail("test@mail.com");
        user.setUsername("ninggc");
        System.out.println(ud.updateUserInfo(user));
    }


}