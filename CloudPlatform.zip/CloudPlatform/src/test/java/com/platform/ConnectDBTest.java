package com.platform;

import com.platform.sqltool.ConnectDB;

import java.sql.Connection;

public class ConnectDBTest {
    Connection conn;

    @org.junit.Test
    public void getConnection() {
        conn = ConnectDB.getConnection();
        ConnectDB.closeConnection(conn);
    }

    @org.junit.Test
    public void closeConnection() {

    }
}